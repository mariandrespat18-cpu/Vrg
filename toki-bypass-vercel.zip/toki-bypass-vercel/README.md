# Toki Bypass Key

Proyecto estático listo para Vercel.

## Deploy
1. Sube `index.html` y `vercel.json` a GitHub.
2. Importa el repositorio en Vercel.
3. Pulsa Deploy.

La interfaz abre el sitio oficial de Bypass.vip en una pestaña nueva; no automatiza una API privada.
